
    function AffichageTexte(){
        document.getElementById("myfooterJS").innerHTML =
        "L'ENSIBS  devient la 5ème Ecole associé au réseau Polytech";
    
    }
